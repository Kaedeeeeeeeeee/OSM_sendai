Map data (c) OpenStreetMap contributors, https://www.openstreetmap.org
Extracts created by BBBike, https://extract.bbbike.org
osmium2shape by Geofabrik, https://geofabrik.de


Please read the OSM wiki how to use shape files.

  https://wiki.openstreetmap.org/wiki/Shapefiles


This shape file was created on: Thu  5 Feb 12:18:50 UTC 2026
GPS rectangle coordinates (lng,lat): 140.796,38.213 x 140.947,38.32
Script URL: https://extract.bbbike.org/?sw_lng=140.796&sw_lat=38.213&ne_lng=140.947&ne_lat=38.32&format=shp.zip&coords=140.843%2C38.213%7C140.898%2C38.217%7C140.942%2C38.26%7C140.947%2C38.309%7C140.88%2C38.32%7C140.833%2C38.315%7C140.796%2C38.279%7C140.811%2C38.232&city=%E4%BB%99%E5%8F%B0%E5%B8%82&lang=en
Name of area: 仙台市


We appreciate any feedback, suggestions and a donation!
You can support us via PayPal or bank wire transfer.

  https://extract.bbbike.org/community.html

You can donate any free amount you want. We are happy for every donation,
for 5, 10, 20, or 50 Euro. Whatever you think the service is worth for you,
or you can afford. We need to raise 20 Euro (25 USD) by the end of the day or
600 Euro (700 USD) per month to cover the server costs.
Your donation helps to pay for hosting the service. Many thanks!

thanks, Wolfram Schneider

--
BBBike professional plans: https://extract.bbbike.org/support.html
Planet.osm extracts: https://extract.bbbike.org
BBBike Map Compare: https://mc.bbbike.org
